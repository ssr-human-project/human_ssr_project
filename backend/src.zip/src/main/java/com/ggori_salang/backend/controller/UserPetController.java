package com.human.middle.controller;

import com.human.middle.dto.UserPetReq;
import com.human.middle.dto.UserPetRes;
import com.human.middle.service.UserPetService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/users")
public class UserPetController {

    private final UserPetService userPetService;

    @GetMapping("/{userId}/pet")
    public ResponseEntity<UserPetRes> getPet(@PathVariable Long userId) {
        UserPetRes pet = userPetService.getPet(userId);
        return ResponseEntity.ok(pet);
    }

    @PutMapping("/{userId}/pet")
    public ResponseEntity<UserPetRes> savePet(
            @PathVariable Long userId,
            @RequestBody UserPetReq req
    ) {
        UserPetRes savedPet = userPetService.savePet(userId, req);
        return ResponseEntity.ok(savedPet);
    }
}
