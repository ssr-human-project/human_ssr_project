package com.human.middle.dao;

import com.human.middle.dto.UserPetReq;
import com.human.middle.dto.UserPetRes;
import lombok.RequiredArgsConstructor;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
@RequiredArgsConstructor
public class UserPetDao {

    private final JdbcTemplate jdbcTemplate;

    public Optional<UserPetRes> findByUserId(Long userId) {
        String sql = """
                SELECT
                    pet_id AS petId,
                    user_id AS userId,
                    pet_name AS petName,
                    pet_type AS petType,
                    breed,
                    size_type AS sizeType,
                    weight,
                    description
                FROM USER_PETS
                WHERE user_id = ?
                """;

        try {
            UserPetRes pet = jdbcTemplate.queryForObject(
                    sql,
                    BeanPropertyRowMapper.newInstance(UserPetRes.class),
                    userId
            );
            return Optional.ofNullable(pet);
        } catch (EmptyResultDataAccessException e) {
            return Optional.empty();
        }
    }

    public int insert(Long userId, UserPetReq req) {
        String sql = """
                INSERT INTO USER_PETS
                    (pet_id, user_id, pet_name, pet_type, breed, size_type, weight, description)
                VALUES
                    (SEQ_USER_PET.NEXTVAL, ?, ?, ?, ?, ?, ?, ?)
                """;

        return jdbcTemplate.update(
                sql,
                userId,
                req.getPetName(),
                req.getPetType(),
                req.getBreed(),
                req.getSizeType(),
                req.getWeight(),
                req.getDescription()
        );
    }

    public int update(Long userId, UserPetReq req) {
        String sql = """
                UPDATE USER_PETS
                SET
                    pet_name = ?,
                    pet_type = ?,
                    breed = ?,
                    size_type = ?,
                    weight = ?,
                    description = ?
                WHERE user_id = ?
                """;

        return jdbcTemplate.update(
                sql,
                req.getPetName(),
                req.getPetType(),
                req.getBreed(),
                req.getSizeType(),
                req.getWeight(),
                req.getDescription(),
                userId
        );
    }
}
